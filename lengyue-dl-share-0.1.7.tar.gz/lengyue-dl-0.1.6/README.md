# 冷月深度学习组件
为自有代码提供 Backbone 和 Dataset

## 安装
发行版
```shell script
pip3 install lengyue-dl -i https://pypi.lengyue.me/simple/
```
测试版
```shell script
pip3 install git+https://github.com/lengyue-private/lengyue-dl
```

## 无 Torch 模式
如果未安装 Torch 将自动采用 Numpy 运算, 但是只有 Utils 可用  

手动禁用 PyTorch  
```python3
# 手动启动
os.environ["DISABLE_TORCH"] = "TRUE"  # 设置环境变量
```

## 发行
```shell script
python3 setup.py sdist
twine upload -r lengyue dist/*
```