from .general import CBAModule, UpSampleModule

__all__ = ['CBAModule', 'UpSampleModule']
