from setuptools import setup, find_packages

setup(
    name='lengyue-dl',
    version='0.1.7',
    packages=find_packages(),
    author='LENGYUE',
    author_email='lengyue@lengyue.com',
    license='Apache',
    url='https://lengyue.me',
    install_requires=[
        'numpy',
        'tqdm',
        'opencv-python',
        'numpy'
    ],
    tests_require=[
        'pytest',
        'twine',
        'flake8'
    ]
)
